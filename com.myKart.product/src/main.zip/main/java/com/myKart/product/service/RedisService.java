package com.myKart.product.service;

import com.fasterxml.jackson.databind.ObjectMapper;

import java.util.concurrent.TimeUnit;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Service;

@Service
public class RedisService {
	
	private static final Logger LOGGER = LogManager.getLogger(RedisService.class);
		
    @Autowired
    private RedisTemplate redisTemplate;

    public <T> T get(String key, Class<T> entityClass) {
        try{
            Object obj = redisTemplate.opsForValue().get(key);
            ObjectMapper mapper = new ObjectMapper();
            return mapper.readValue(obj.toString(), entityClass);
        }catch(Exception e){
        	LOGGER.error("Exception ",e.getMessage());
        	return null;
        }
    }

    
    public void set(String key, Object o,Long ttl) {
        try{
            redisTemplate.opsForValue().set(key,o.toString(),ttl,TimeUnit.SECONDS);
        }catch(Exception e){
        	LOGGER.error("Exception ",e.getMessage());
        }
    }

    
}
