package com.myKart.product.service;

import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.aggregation.Aggregation;
import org.springframework.data.mongodb.core.aggregation.AggregationResults;
import org.springframework.stereotype.Service;

import com.myKart.infra.exception.BussinessException;
import com.myKart.product.dto.Product;
import com.myKart.product.repository.ProductRepository;

@Service
public class ProductService {

	Date date = new Date();
	

	@Autowired
	ProductRepository productRepository;

	@Autowired
	private MongoTemplate mongoTemplate;

	@Autowired
	private RedisService redisService;

	public String addProduct(Product newProduct) throws Exception {
		try {
			productRepository.save(newProduct);
		} catch (Exception e) {
			throw new Exception(e.getMessage());
		}
		return "Added";
	}

	public Product getProduct(String productId) throws Exception {
		Product product;
		try {
			product = redisService.get(productId, Product.class);
			if (product != null) {
				return product;
			} else {
				product = productRepository.findByProductId(productId);
				if (product == null) {
					throw new BussinessException("Product Not Found");
				} else {
					redisService.set(productId, product, 3600L);
				}
			}

		} catch (Exception e) {
			throw new Exception(e.getMessage());
		}
		return product;
	}

	public List<Product> getAllProduct() throws Exception {
		List<Product> productList;
		try {
			productList = productRepository.findAll();
		} catch (Exception e) {
			throw new Exception(e.getMessage());
		}
		return productList;
	}

	public List<Product> getRandomProduct() throws Exception{
	    try {
	        String cacheKey = "product:random:5";

	        // 1. Try from Redis
	        List<Product> productList = redisService.get(cacheKey, List.class);
	        if (productList != null && !productList.isEmpty()) {
	            return productList;
	        }

	        // 2. Fallback to DB (Mongo aggregation)
	        Aggregation aggregation = Aggregation.newAggregation(Aggregation.sample(5));
	        AggregationResults<Product> results = mongoTemplate.aggregate(aggregation, "Product", Product.class);
	        productList = results.getMappedResults();

	        if (productList == null || productList.isEmpty()) {
	            throw new BussinessException("No Random Products Found");
	        }

	        // 3. Save result in Redis (short TTL since it's random)
	        redisService.set(cacheKey, productList, 3600L);

	        return productList;
	    } catch (BussinessException e) {
	    	throw new BussinessException("Product Not Found"); // Preserve domain exception
	    } catch (Exception e) {
	        throw new RuntimeException("Failed to fetch random products", e);
	    }
	}

	public List<Product> getProductByBrandName(String brandName) throws Exception {
	    try {
	        String cacheKey = "brand:" + brandName;

	        // 1. Try from Redis
	        List<Product> productList = redisService.get(cacheKey, List.class);
	        if (productList != null && !productList.isEmpty()) {
	            return productList;
	        }

	        // 2. Fallback to DB
	        productList = productRepository.findByBrandNameContaining(brandName);
	        if (productList == null || productList.isEmpty()) {
	            throw new BussinessException("No Products found for brand: " + brandName);
	        }

	        // 3. Save result in Redis
	        redisService.set(cacheKey, productList, 3600L);

	        return productList;
	    } catch (BussinessException e) {
	    	throw new BussinessException("Brand not Found"); // Preserve domain-specific exception
	    } catch (Exception e) {
	        throw new RuntimeException("Failed to fetch products for brand: " + brandName, e);
	    }
	}


}
